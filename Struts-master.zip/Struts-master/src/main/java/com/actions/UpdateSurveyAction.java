package com.actions;

import com.opensymphony.xwork2.ActionSupport;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.helper.FactoryProvider;
import com.vignan.Survey;

public class UpdateSurveyAction extends ActionSupport {
    private int id;             // Survey ID
    private String title;       // Survey title
    private String description; // Survey description
    private String question;     // Single survey question

    public String update() {
        Session session = FactoryProvider.getFactory().openSession();
        Transaction tx = null;

        try {
            tx = session.beginTransaction();
            Survey survey = session.get(Survey.class, id); // Fetch the survey by ID

            if (survey != null) {
                // Update survey information
                survey.setTitle(title);
                survey.setDescription(description);
                survey.setQuestion(question);
                session.merge(survey); // Merge the updated survey
                tx.commit();
                addActionMessage("Survey updated successfully!");
                return SUCCESS;
            } else {
                addActionError("Survey with ID " + id + " not found.");
                return ERROR;
            }
        } catch (Exception e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
            addActionError("Error updating survey: " + e.getMessage());
            return ERROR;
        } finally {
            session.close();
        }
    }

    // Getters and setters for form fields
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }
}
